# TweakScale Companion :: Rockets :: Change Log

* 2020-0806: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ Initial Public Release
	+ Adds support for:
		- Real Engines
